// Leírás: https://github.com/green-fox-academy/teaching-materials/blob/master/workshop/firestore/js.hu.md
const config = {
  apiKey: "AIzaSyC9E55zWd-d6YTwYNdB5VAEjscUwONAqbE",
  authDomain: "hsg-final-exam-e229d.firebaseapp.com",
  projectId: "hsg-final-exam-e229d",
  storageBucket: "hsg-final-exam-e229d.appspot.com",
  messagingSenderId: "1079463821075",
  appId: "1:1079463821075:web:a2bc27c20601bd0faae4e6"
};

export default config;
